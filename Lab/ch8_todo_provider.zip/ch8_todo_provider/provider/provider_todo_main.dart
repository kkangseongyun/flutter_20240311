import 'package:flutter/material.dart';

import 'package:provider/provider.dart';



void main() => runApp(TodosApp());

class TodosApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    //add.................................
    
  }
}